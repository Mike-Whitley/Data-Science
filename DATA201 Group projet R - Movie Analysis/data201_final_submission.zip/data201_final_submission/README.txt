All the deliverables are in this zip

The graphs are png's inside the Graphs folder
The datasets are .rda's inside the Datasets folder

Data201_Movie analysis_GROUP_DIARY.pdf
	- A journal of what each of us worked on when we met up.

Data201_Movie analysis_PRESENTATION.pdf
	- A pdf file of the presentation we presented in the lab

Data201_Movie analysis_REPORT.pdf
	-Our final report in pdf format

Data201_Movie analysis_CODE.ipynb
	- Our final code used for collecting and wrangling the data.
	- This should be opened in juputer-lab

Data201_Movie analysis_ETHICS.md
	- An ethics checklist, this can be opened in jupyter-lab

the_numbers_api.rda
	- This is a dataframe of the api data using the numbers titles

the_numbers_df.rda
	- Web scraped data from www.the-numbers.com

tomato_api.rda
	- This is a dataframe of the api data using the rotten tomatoes titles

tomato_df.rda
	- Web scraped data from www.rottentomatoes.com

combination_api.rda 
	- This is a combination of both sets of API data


This is the code to read in the rda files within r (jupyter-lab)

Combination_api <- readRDS("Combination_api.Rda") # Combined Numbers and Rotten Tomato API scrape
the_numbers_api <- readRDS("the_numbers_api.Rda") # Numbers API Scrape
the_numbers_df <- readRDS("the_numbers_df.Rda") # Numbers Web Scrape
tomato_api <- readRDS("tomato_api.Rda") # Rotten Tomato API Scrape
tomato_df <- readRDS("tomato_df.Rda") # Rotten Tomato Web Scrape



